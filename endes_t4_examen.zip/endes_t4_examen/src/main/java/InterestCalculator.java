public class InterestCalculator {
    public final static int dias = 365;

    double calculateInterest(double principal, double rate, int time) {
        // Cálculo del interés compuesto para 365 días al año
        return interesCompuesto(principal, rate, time);
    }

    private static double interesCompuesto(double principal, double rate, int time) {
        return principal * Math.pow(1 + (rate / dias), time * dias);
    }
}