public class Report {
    void printReport() {

        // imprimir título
        imprimir();

        // contenido del reporte
        System.out.println("Contenido 1...");
        System.out.println("Contenido 2...");
        // más contenido...

        // imprimir conclusión
        conclusion();
    }

    private static void conclusion() {
        System.out.println("Conclusión del Reporte");
    }

    private static void imprimir() {
        System.out.println("Título del Reporte");
    }
}