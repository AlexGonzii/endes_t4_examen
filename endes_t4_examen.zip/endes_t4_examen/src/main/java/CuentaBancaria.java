/**
 * Clase que representa una cuenta bancaria
 * La cuenta bancaria representa una entidad en la que se guarda dinero
 * @author Alexis
 * @version 1.0 12/03/2024
 */
public class CuentaBancaria {
    private String numeroCuenta;
    private double saldo;
    private Cliente propietario;
/**
 * Constructor de CuentaBancaria en el que nos interesa saber el número de la cuenta, el saldo y el propietario
 * @param numeroCuenta El número de la cuenta
 * @param propietario El propietario de la cuenta
 * @param saldo El saldo que tiene la cuenta*/
    public CuentaBancaria(String numeroCuenta, double saldo, Cliente propietario) {
        this.numeroCuenta = numeroCuenta;
        this.saldo = saldo;
        this.propietario = propietario;
    }
/**
 * Método getter para obtener el número de la cuenta
 * @return numeroCuenta
 */
    public String getNumeroCuenta() {
        return numeroCuenta;
    }
 /**
  * Método setter para establecer el número de la cuenta
  * @param numeroCuenta El número de la cuenta
  */
    public void setNumeroCuenta(String numeroCuenta) {
        this.numeroCuenta = numeroCuenta;
    }
 /**
  * Método getter para obtener el saldo de la cuenta
  * @return saldo
 */
    public double getSaldo() {
        return saldo;
    }
 /**
  * Método getter para obtener el número de la cuenta
  * @param saldo  El saldo de la cuenta
 */
    public void setSaldo(double saldo) {
        this.saldo = saldo;
    }
 /**
  * Método getter para obtener el propietario de la cuenta
  * @return propietario
 */
    public Cliente getPropietario() {
        return propietario;
    }
 /**
  * Método setter para establecer el número de la cuenta
  * @param propietario El propietario de la cuenta
 */
    public void setPropietario(Cliente propietario) {
        this.propietario = propietario;
    }
 /**
  * Método vacío que se llama depositar al que se le pasa como parámetro cantidad
  * @param cantidad La cantidad a depositar en la cuenta
 */
    public void depositar(double cantidad) {
        saldo += cantidad;
    }
 /**
  * Método booleano que se llama retirar al que se le pasa como parámetro cantidad
  * @return verdadero o falso en función de si se cumple la condición o no
 */
    public boolean retirar(double cantidad) {
        if (cantidad <= saldo) {
            saldo -= cantidad;
            return true;
        }
        return false;
    }
 /**
  * Método toString que convierte la estancia en un String
  * Método que devuelve todos los datos de la cuenta bancaria
  * @return Un String con el número de cuenta, saldo y el propietario donde se incluye el nombre y apellido
 */
    @Override
    public String toString() {
        return "CuentaBancaria{" +
                "numeroCuenta='" + numeroCuenta + '\'' +
                ", saldo=" + saldo +
                ", propietario=" + propietario.getNombre() + " " + propietario.getApellido() +
                '}';
    }
}
