public class DistanceCalculator {
    double metros;
    double segundos;

    public double calculateDistance(double metros, double segundos) {
        return metros * segundos;
    }
}