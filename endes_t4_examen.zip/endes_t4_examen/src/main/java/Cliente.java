

import java.util.ArrayList;
import java.util.List;
/**
 * Clase que representa un cliente
 * El cliente representa una entidad que tiene una cuenta en el banco
 * @author Alexis
 * @version 1.0 12/03/2024
 * */
public class Cliente {
    private String nombre;
    private String apellido;
    private String id;
    private List<CuentaBancaria> cuentas;
/**
 * Constructor del cliente en el que nos interesa saber su nombre,apellido,id y las cuentas que posee
 * @param nombre El nombre del cliente
 * @param apellido El apellido del cliente
 * @param id El identificador del cliente
 * */
    public Cliente(String nombre, String apellido, String id) {
        this.nombre = nombre;
        this.apellido = apellido;
        this.id = id;
        this.cuentas = new ArrayList<>();
    }
/**
 * Método getter para obtener el nombre del cliente
 * @return nombre
 */
    public String getNombre() {
        return nombre;
    }
/**
 * Método setter para establecer el nombre del cliente
 * @param nombre El nombre del cliente
 */
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }
/**
 * Método getter para obtener el apellido
 * @return apellido
 */
    public String getApellido() {
        return apellido;
    }
/**
 * Método setter para establecer el apellido del cliente
 * @param apellido El apellido del cliente
 */
    public void setApellido(String apellido) {
        this.apellido = apellido;
    }
/**
 * Método getter para obtener el id del cliente
 * @return id
 */
    public String getId() {
        return id;
    }
/**
 * Método setter para establecer el id del cliente
 * @param id El identificador del cliente
 */
    public void setId(String id) {
        this.id = id;
    }
/**
 * Método getter para obtener una lista con el número de cuentas que posee
 *@return cuentas
 * Devuelve el número de cuentas a través de un array*/
    public List<CuentaBancaria> getCuentas() {
        return new ArrayList<>(cuentas);
    }
/**
 * Método vacío llamaado agregarCuenta
 * En el se añade las cuentas que el cliente posea*/
    public void agregarCuenta(CuentaBancaria cuenta) {
        cuentas.add(cuenta);
    }
/**
 * Método booleano llamado cerrarCuenta
 * @param numeroCuenta Se le pasa el numero de cuenta
 * @return verdadero o falso en función de si se cumple la condición establecida*/
    public boolean cerrarCuenta(String numeroCuenta) {
        return cuentas.removeIf(cuenta -> cuenta.getNumeroCuenta().equals(numeroCuenta));
    }
/**
 * Método toString que convierte la estancia en un String
 * Método que devuelve todos los datos del cliente
 * @return Un String con el nombre,apellido,id y las cuentas
 */
    @Override
    public String toString() {
        return "Cliente{" +
                "nombre='" + nombre + '\'' +
                ", apellido='" + apellido + '\'' +
                ", id='" + id + '\'' +
                ", cuentas=" + cuentas +
                '}';
    }
}
